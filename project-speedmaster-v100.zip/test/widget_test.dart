import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:speedmaster/main.dart';

// Widget test: native channel ka mock asal jaisi values deta hai —
// LTE (13) + koi 5G override nahi. App ko "4G" hi dikhana chahiye:
// mock ke LTE par jhoota "5G" dikhana sab se bara fail hoga.
void main() {
  const channel = MethodChannel('com.bozdar.speedmaster/native');

  setUp(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (MethodCall call) async {
      switch (call.method) {
        case 'getNetworkInfo':
          return <String, dynamic>{
            'permissionGranted': true,
            'operatorName': 'Test Operator',
            'dataNetworkType': 13, // LTE
            'overrideNetworkType': 0, // koi 5G override nahi
            'hasCellService': true,
            'signalDbm': -85,
            'isWifiConnected': false,
          };
        case 'getDisplayInfo':
          return <String, dynamic>{
            'currentHz': 90.0,
            'supportedHz': <double>[60.0, 90.0],
          };
        case 'getBatteryInfo':
          return <String, dynamic>{
            'levelPct': 80,
            'healthCode': 2,
            'tempC': 30.0,
            'voltageV': 4.1,
            'cycleCount': -1,
            'plugged': false,
            'isCharging': false,
            'currentUa': null,
          };
        default:
          return null;
      }
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  testWidgets('Home screen — asal 4G dikhta hai, imaandari line maujood hai',
      (tester) async {
    await tester.pumpWidget(const SpeedMasterApp());
    // Native jawabon ke baad frames pump karo jab tak card update na ho.
    for (var i = 0; i < 20; i++) {
      await tester.pump(const Duration(milliseconds: 100));
      if (find.text('4G').evaluate().isNotEmpty) break;
    }

    expect(find.text('5G Speed Master'), findsOneWidget);
    expect(find.text('v1.0.0'), findsOneWidget);
    // LOCKED imaandari sentence.
    expect(
      find.textContaining('Ye app signal nahi barhati'),
      findsOneWidget,
    );
    expect(find.textContaining('asal signal, asal speed'), findsOneWidget);
    // Mock LTE hai — bara label "4G" hona chahiye, "5G" KABHI nahi.
    expect(find.text('4G'), findsOneWidget);
    expect(find.text('5G'), findsNothing);
    expect(find.text('-85 dBm • Acha'), findsOneWidget);
    expect(find.text('Test Operator'), findsOneWidget);
    // Zaroori sections ke button maujood hain (ListView neeche scroll
    // karke lazily-built cards bhi check kar lo).
    expect(find.text('5G Setting Kholein'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('5G Scanner Kholein'), 200);
    expect(find.text('5G Scanner Kholein'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('Speed Test Karein'), 200);
    expect(find.text('Speed Test Karein'), findsOneWidget);
    // Display ka faisla asal list [60, 90] se: 120 support NAHI.
    await tester.scrollUntilVisible(
      find.text('Display Speed Setting Kholein'),
      200,
    );
    expect(
      find.textContaining('Is phone par 120 Hz support nahi'),
      findsOneWidget,
    );

    // Screen dispose karke 3-second wala timer band karo.
    await tester.pumpWidget(const SizedBox());
  });
}
