import 'package:flutter_test/flutter_test.dart';
import 'package:speedmaster/logic.dart';
import 'package:speedmaster/place_log.dart';

// Saare test ASAL logic ke hain — koi bana hua number in se pass nahi
// hota: haddain, label aur hisaab bilkul wahi jo app mein chalta hai.

void main() {
  group('networkTypeLabel — asal type, jhoota 5G kabhi nahi', () {
    String label({
      int data = 0,
      int override = 0,
      bool wifi = false,
      bool service = true,
    }) =>
        networkTypeLabel(
          dataNetworkType: data,
          overrideNetworkType: override,
          isWifiConnected: wifi,
          hasCellService: service,
        );

    test('NR (20) = 5G', () => expect(label(data: 20), '5G'));
    test('LTE + NR_NSA override (3) = 5G', () {
      expect(label(data: 13, override: 3), '5G');
    });
    test('LTE + NR_NSA_MMWAVE override (4) = 5G', () {
      expect(label(data: 13, override: 4), '5G');
    });
    test('LTE + NR_ADVANCED override (5) = 5G', () {
      expect(label(data: 13, override: 5), '5G');
    });
    test('LTE (13) = 4G', () => expect(label(data: 13), '4G'));
    test('LTE_CA (19) = 4G', () => expect(label(data: 19), '4G'));
    test('LTE + LTE_CA override (1) phir bhi 4G — 5G nahi banta', () {
      expect(label(data: 13, override: 1), '4G');
    });
    test('UMTS (3) = 3G', () => expect(label(data: 3), '3G'));
    test('HSPA (10) = 3G', () => expect(label(data: 10), '3G'));
    test('HSPAP (15) = 3G', () => expect(label(data: 15), '3G'));
    test('EDGE (2) = 2G', () => expect(label(data: 2), '2G'));
    test('GPRS (1) = 2G', () => expect(label(data: 1), '2G'));
    test('Wi-Fi sab par bhaari', () {
      expect(label(data: 20, wifi: true), 'Wi-Fi');
    });
    test('unknown + service = Maloom nahi', () {
      expect(label(data: 0, service: true), 'Maloom nahi');
    });
    test('unknown + koi service nahi = Koi network nahi', () {
      expect(label(data: 0, service: false), 'Koi network nahi');
    });
  });

  group('signalQuality — dBm haddain', () {
    test('-70 = Bohat acha (level 4)', () {
      final q = signalQuality(-70);
      expect(q.level, 4);
      expect(q.word, 'Bohat acha');
    });
    test('-71 aur -85 = Acha (level 3)', () {
      expect(signalQuality(-71).word, 'Acha');
      expect(signalQuality(-85).level, 3);
    });
    test('-86 aur -100 = Darmiyana (level 2)', () {
      expect(signalQuality(-86).word, 'Darmiyana');
      expect(signalQuality(-100).level, 2);
    });
    test('-101 aur -110 = Kamzor (level 1)', () {
      expect(signalQuality(-101).word, 'Kamzor');
      expect(signalQuality(-110).level, 1);
    });
    test('-111 = Bohat kamzor (level 0)', () {
      final q = signalQuality(-111);
      expect(q.level, 0);
      expect(q.word, 'Bohat kamzor');
    });
  });

  group('speed hisaab', () {
    test('5 MB ek second mein = 40 Mbps', () {
      expect(
        mbpsFromBytes(5000000, const Duration(seconds: 1)),
        closeTo(40.0, 0.001),
      );
    });
    test('0 bytes = 0 Mbps', () {
      expect(mbpsFromBytes(0, const Duration(seconds: 1)), 0);
    });
    test('formatMbps: 100 se kam par 1 decimal', () {
      expect(formatMbps(42.36), '42.4 Mbps');
      expect(formatMbps(8.0), '8.0 Mbps');
    });
    test('formatMbps: 100+ par baghair decimal', () {
      expect(formatMbps(123.4), '123 Mbps');
    });
  });

  group('battery health labels', () {
    test('2 = Achi haalat', () => expect(batteryHealthLabel(2), 'Achi haalat'));
    test('3 = garam', () => expect(batteryHealthLabel(3), 'Battery garam hai'));
    test('4 = kharab', () {
      expect(batteryHealthLabel(4), 'Battery kharab hai');
    });
    test('5 = voltage zyada', () {
      expect(batteryHealthLabel(5), 'Voltage zyada hai');
    });
    test('1 / ajnabi code = Maloom nahi', () {
      expect(batteryHealthLabel(1), 'Maloom nahi');
      expect(batteryHealthLabel(99), 'Maloom nahi');
    });
  });

  group('charging watts', () {
    test('3A x 5V = 15W aur fast charging', () {
      final w = chargingWatts(currentMicroAmps: 3000000, voltageVolts: 5.0);
      expect(w, closeTo(15.0, 0.001));
      expect(isFastCharging(w), isTrue);
    });
    test('ulta sign wala current bhi absolute banta hai', () {
      final w = chargingWatts(currentMicroAmps: -2000000, voltageVolts: 9.0);
      expect(w, closeTo(18.0, 0.001));
    });
    test('15W se kam = fast NAHI', () {
      expect(isFastCharging(14.9), isFalse);
      expect(isFastCharging(7.5), isFalse);
    });
    test('formatWatts', () {
      expect(formatWatts(15.04), '15.0 W');
      expect(formatWatts(7.26), '7.3 W');
    });
  });

  group('refresh rate support — asal list se faisla', () {
    test('[60, 90] mein 120 NAHI hai (OnePlus 8 wala case)', () {
      expect(supportsRefreshRate([60, 90], 120), isFalse);
    });
    test('[60, 90, 120] mein 120 hai', () {
      expect(supportsRefreshRate([60, 90, 120], 120), isTrue);
    });
    test('119.98 bhi 120 hi mana jata hai (tolerance)', () {
      expect(supportsRefreshRate([60, 119.98], 120), isTrue);
    });
    test('90 support ka check', () {
      expect(supportsRefreshRate([60, 90], 90), isTrue);
    });
    test('maxRefreshRate', () {
      expect(maxRefreshRate([60, 90]), 90);
      expect(maxRefreshRate([120, 60, 90]), 120);
      expect(maxRefreshRate([]), isNull);
    });
    test('uniqueSortedRates — duplicate aur tartib', () {
      expect(uniqueSortedRates([90, 60, 90, 120]), [60, 90, 120]);
    });
    test('formatHz', () {
      expect(formatHz(90), '90 Hz');
      expect(formatHz(119.98), '120.0 Hz');
      expect(formatHz(59.5), '59.5 Hz');
    });
  });

  group('usage numaish', () {
    test('formatDurationMs', () {
      expect(formatDurationMs(30000), '1 minute se kam');
      expect(formatDurationMs(2700000), '45 minute');
      expect(formatDurationMs(3600000), '1 ghante');
      expect(formatDurationMs(7500000), '2 ghante 5 minute');
    });
    test('formatBytes', () {
      expect(formatBytes(500), '500 B');
      expect(formatBytes(850 * 1024), '850 KB');
      expect(formatBytes(350 * 1024 * 1024), '350 MB');
      expect(formatBytes((1.2 * 1024 * 1024 * 1024).round()), '1.2 GB');
    });
  });

  group('5G Scanner — faasla, waqt, coverage URL', () {
    test('wohi jagah = 0 meter', () {
      expect(distanceMeters(24.8608, 67.0011, 24.8608, 67.0011), 0);
    });
    test('0.01 degree shumaal = taqreeban 1112 meter', () {
      final d = distanceMeters(24.8608, 67.0011, 24.8708, 67.0011);
      expect(d, inInclusiveRange(1050, 1180));
    });
    test('formatDateTime — local waqt sahi banta hai', () {
      final ms = DateTime(2026, 11, 12, 15, 45).millisecondsSinceEpoch;
      expect(formatDateTime(ms), '12 Nov 2026, 3:45 PM');
      final mid = DateTime(2026, 1, 5, 0, 5).millisecondsSinceEpoch;
      expect(formatDateTime(mid), '5 Jan 2026, 12:05 AM');
      final noon = DateTime(2026, 6, 30, 12, 0).millisecondsSinceEpoch;
      expect(formatDateTime(noon), '30 Jun 2026, 12:00 PM');
    });
    test('coverageUrlForOperator — official sites', () {
      expect(coverageUrlForOperator('Jazz'), 'https://www.jazz.com.pk');
      expect(coverageUrlForOperator('Zong CMPak'), 'https://www.zong.com.pk');
      expect(coverageUrlForOperator('UFONE'), 'https://www.ufone.com');
      expect(
        coverageUrlForOperator('Telenor Pakistan'),
        'https://www.telenor.com.pk',
      );
      expect(coverageUrlForOperator(''), 'https://www.pta.gov.pk');
      expect(coverageUrlForOperator('Koi Ajnabi'), 'https://www.pta.gov.pk');
    });
    test('PlaceEntry JSON roundtrip', () {
      const e = PlaceEntry(
        timeMs: 1760000000000,
        dbm: -82,
        lat: 24.8608,
        lng: 67.0011,
        area: 'Clifton, Karachi',
      );
      final back = PlaceEntry.fromJson(e.toJson());
      expect(back.timeMs, e.timeMs);
      expect(back.dbm, -82);
      expect(back.lat, 24.8608);
      expect(back.lng, 67.0011);
      expect(back.area, 'Clifton, Karachi');
    });
    test('PlaceEntry baghair location ke bhi sahi parhi jati hai', () {
      const e = PlaceEntry(timeMs: 5, dbm: null, lat: null, lng: null, area: '');
      final back = PlaceEntry.fromJson(e.toJson());
      expect(back.dbm, isNull);
      expect(back.lat, isNull);
      expect(back.area, '');
    });
  });
}
