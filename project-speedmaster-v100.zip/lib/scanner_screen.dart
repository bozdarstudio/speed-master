import 'dart:async';

import 'package:flutter/material.dart';

import 'logic.dart';
import 'native.dart';
import 'place_log.dart';

/// 5G Scanner — modem hi asal scanner hai: is jagah ki mojooda asal
/// haalat (TelephonyManager se) + "Jahan 5G Mila" ki asal mehfooz
/// jaghein. Doosre ilaqon ka haal operator ke official coverage map
/// par milta hai — app ke andar koi nakli map NAHI hai.
class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  static const _green = Color(0xFF1B5E20);
  static const _gold = Color(0xFFC9A227);

  NetworkInfo? _net;
  List<PlaceEntry> _places = const [];
  bool _locGranted = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _tick();
    // Scanner khula ho to haalat har 3 second taza — aur asal 5G mile
    // to entry bhi isi dauran mehfooz hoti hai (FiveGPlaceLog).
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _tick() async {
    final net = await NativeChannel.getNetworkInfo();
    await FiveGPlaceLog.maybeRecord(net);
    final places = await FiveGPlaceLog.load();
    final granted = await NativeChannel.hasLocationPermission();
    if (!mounted) return;
    setState(() {
      _net = net;
      _places = places;
      _locGranted = granted;
    });
  }

  /// "Is jagah abhi: ..." — hamesha asal label se banta hai.
  String _nowText(NetworkInfo net) {
    switch (net.typeLabel) {
      case '5G':
        return '5G hai';
      case '4G':
        return '4G hai';
      case '3G':
        return '3G hai';
      case '2G':
        return '2G hai';
      case 'Wi-Fi':
        return 'Wi-Fi hai';
      case 'Koi network nahi':
        return 'Koi network nahi';
      default:
        return 'Asal haal maloom nahi ho saka';
    }
  }

  Future<void> _requestLocation() async {
    final ok = await NativeChannel.requestLocationPermission();
    if (!mounted) return;
    setState(() => _locGranted = ok);
    _tick();
  }

  Future<void> _openCoverage() async {
    final url = coverageUrlForOperator(_net?.operatorName ?? '');
    final ok = await NativeChannel.openCoverageMap(url);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Operator ki official website khul gayi hai — wahan 5G coverage map dekhein.'
              : 'Coverage map nahi khul saka — browser check karein.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final net = _net;
    return Scaffold(
      appBar: AppBar(title: const Text('5G Scanner')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // --- Is jagah ki asal haalat --------------------------------
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            decoration: BoxDecoration(
              color: _green,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                const Text(
                  'IS JAGAH ABHI',
                  style: TextStyle(
                    color: _gold,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  net == null ? 'Parh raha hai…' : _nowText(net),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  net == null
                      ? ''
                      : net.signalDbm != null
                          ? '${net.signalDbm} dBm • ${signalQuality(net.signalDbm!).word}'
                          : net.permissionGranted
                              ? 'Signal maloom nahi'
                              : 'Signal ki permission nahi mili',
                  style: const TextStyle(color: Colors.white70, fontSize: 15),
                ),
                if (net != null && net.operatorName.isNotEmpty)
                  Text(
                    net.operatorName,
                    style: const TextStyle(color: Colors.white70, fontSize: 14),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (!_locGranted)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Jagah ke naam ke liye location ki ijazat dein. Ijazat '
                      'na ho to bhi waqt aur signal wali entry mehfooz hoti '
                      'hai — sirf jagah nahi likhi jati.',
                      style: TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _requestLocation,
                        icon: const Icon(Icons.location_on),
                        label: const Text('Location Ki Ijazat Dein'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (!_locGranted) const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _openCoverage,
              icon: const Icon(Icons.map),
              label: const Text(
                'Operator Ka 5G Coverage Map',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
              ),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'Doosre ilaqon ka haal operator ke map par milta hai; ye '
            'scanner aap ki apni jagah ka asal haal aur aap ki 5G wali '
            'jaghein dikhata hai.',
            style: TextStyle(fontSize: 13, color: Colors.black54),
          ),
          const SizedBox(height: 20),
          // --- Jahan 5G Mila -------------------------------------------
          Row(
            children: [
              const Icon(Icons.place, color: _green),
              const SizedBox(width: 8),
              Text(
                'Jahan 5G Mila (${_places.length})',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (_places.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Abhi tak koi 5G jagah mehfooz nahi hui. Jab phone asal '
                  '5G par hoga aur app khuli hogi, woh jagah khud yahan '
                  'aa jayegi.',
                  style: TextStyle(fontSize: 14),
                ),
              ),
            )
          else
            ..._places.reversed.map((p) {
              final title = p.area.isNotEmpty
                  ? p.area
                  : p.lat != null
                      ? 'Jagah ka naam nahi mila'
                      : 'Baghair location wali jagah';
              final coords = p.lat != null && p.lng != null
                  ? ' • ${p.lat!.toStringAsFixed(4)}, ${p.lng!.toStringAsFixed(4)}'
                  : '';
              final dbm = p.dbm != null ? ' • ${p.dbm} dBm' : '';
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.signal_cellular_alt, color: _gold),
                  title: Text(title),
                  subtitle: Text('${formatDateTime(p.timeMs)}$dbm$coords'),
                ),
              );
            }),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
