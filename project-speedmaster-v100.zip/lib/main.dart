import 'dart:async';

import 'package:flutter/material.dart';

import 'logic.dart';
import 'native.dart';
import 'place_log.dart';
import 'scanner_screen.dart';
import 'speed_test.dart';
import 'version.dart';

// ---------------------------------------------------------------------------
// Bozdar 5G Speed Master v1.0.0
//
// HONESTY LOCK (owner ka hukm): ye app signal NAHI barhati, speed NAHI
// banati, Hz NAHI badhati, charging watts NAHI barhati. Ye sirf:
//   - phone ki ASAL network haalat live dikhati hai (TelephonyManager),
//   - asal download naap kar speed test karti hai (dart:io),
//   - asal system settings tak ek tap mein pohchati hai (5G, display,
//     battery saver, airplane mode),
//   - battery aur usage ki ASAL maloomat dikhati hai.
// Jo cheez na mil sake, wahan saaf "maloom nahi / permission nahi mili"
// likha aata hai — jhoota number kabhi nahi.
// ---------------------------------------------------------------------------

void main() {
  runApp(const SpeedMasterApp());
}

class SpeedMasterApp extends StatelessWidget {
  const SpeedMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '5G Speed Master',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B5E20), // gehra sabz
          primary: const Color(0xFF1B5E20),
          secondary: const Color(0xFFC9A227), // sunehri
        ),
        scaffoldBackgroundColor: const Color(0xFFF4F8F4),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1B5E20),
          foregroundColor: Colors.white,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  static const Color _green = Color(0xFF1B5E20);
  static const Color _gold = Color(0xFFC9A227);
  static const TextStyle _noteStyle =
      TextStyle(fontSize: 13, color: Colors.black54);
  static const int _speedTotalBytes = 5000000;

  NetworkInfo? _network;
  DisplayInfo? _display;
  BatteryInfo? _battery;
  bool _usageGranted = false;
  UsageTopApps? _usage;
  Timer? _timer;

  final SpeedTestService _speedTest = SpeedTestService();
  bool _speedTesting = false;
  int _speedBytes = 0;
  SpeedTestResult? _speedResult;
  String? _speedNetworkLabel;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshAll();
    // 5G monitoring default ON — har 3 second mein live network taza.
    _timer = Timer.periodic(
      const Duration(seconds: 3),
      (_) => _refreshNetwork(),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Setting se wapas aane par sab kuch dobara parho — ijazat ya Hz
    // ki tabdeeli foran nazar aye.
    if (state == AppLifecycleState.resumed) {
      _refreshAll();
    }
  }

  Future<void> _refreshNetwork() async {
    final info = await NativeChannel.getNetworkInfo();
    if (!mounted) return;
    setState(() => _network = info);
    // 5G Scanner ka record: phone asal 5G par ho aur app khuli ho to
    // "Jahan 5G Mila" mein entry mehfooz hoti hai (background mein,
    // UI is ka intezaar nahi karti).
    unawaited(FiveGPlaceLog.maybeRecord(info));
  }

  Future<void> _refreshAll() async {
    await _refreshNetwork();
    final display = await NativeChannel.getDisplayInfo();
    final battery = await NativeChannel.getBatteryInfo();
    final granted = await NativeChannel.hasUsageAccess();
    UsageTopApps? usage;
    if (granted) {
      usage = await NativeChannel.getUsageTopApps();
    }
    if (!mounted) return;
    setState(() {
      _display = display;
      _battery = battery;
      _usageGranted = granted;
      _usage = usage;
    });
  }

  Future<void> _openSetting(Future<bool> Function() open) async {
    final ok = await open();
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Setting nahi khul saki — dobara koshish karein'),
        ),
      );
    }
  }

  Future<void> _runSpeedTest() async {
    if (_speedTesting) return;
    setState(() {
      _speedTesting = true;
      _speedBytes = 0;
      _speedResult = null;
      _speedNetworkLabel = _network?.typeLabel ?? 'Maloom nahi';
    });
    final result = await _speedTest.run(
      onProgress: (bytes) {
        if (mounted) setState(() => _speedBytes = bytes);
      },
    );
    if (!mounted) return;
    setState(() {
      _speedTesting = false;
      _speedResult = result;
    });
  }

  // ------------------------------------------------------------------
  // Chhote helper widgets
  // ------------------------------------------------------------------

  Widget _card({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: _green),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _green,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _row(String name, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: Text(name, style: const TextStyle(color: Colors.black54)),
          ),
          Expanded(
            flex: 2,
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bigButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          backgroundColor: _green,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _signalBars(int level) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (var i = 0; i < 4; i++)
          Container(
            width: 6,
            height: 6.0 + i * 4,
            margin: const EdgeInsets.only(right: 2),
            decoration: BoxDecoration(
              color: i < level ? _gold : Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
      ],
    );
  }

  // ------------------------------------------------------------------
  // Sections
  // ------------------------------------------------------------------

  /// Sab se upar BARA live network display — asal type hi dikhta hai:
  /// phone asal 5G (NR) par ho to bara "5G", 4G ho to "4G".
  /// Jhoota 5G kabhi nahi.
  Widget _bigNetworkCard() {
    final net = _network;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
      decoration: BoxDecoration(
        color: _green,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          const Text(
            'LIVE NETWORK',
            style: TextStyle(
              color: _gold,
              letterSpacing: 2,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            net == null ? 'Parh raha hai…' : net.typeLabel,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 64,
              fontWeight: FontWeight.w900,
            ),
          ),
          if (net != null) ...[
            Text(
              net.operatorName.isEmpty
                  ? 'Operator maloom nahi'
                  : net.operatorName,
              style: const TextStyle(color: Colors.white70, fontSize: 16),
            ),
            const SizedBox(height: 14),
            _signalArea(net),
            const SizedBox(height: 10),
            const Text(
              'Har 3 second mein taza hota hai',
              style: TextStyle(color: Colors.white38, fontSize: 12),
            ),
          ],
        ],
      ),
    );
  }

  Widget _signalArea(NetworkInfo net) {
    final dbm = net.signalDbm;
    if (dbm != null) {
      final quality = signalQuality(dbm);
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _signalBars(quality.level),
          const SizedBox(width: 10),
          Text(
            '$dbm dBm • ${quality.word}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      );
    }
    if (!net.permissionGranted) {
      return Column(
        children: [
          const Text(
            'Signal parhne ki permission nahi mili',
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: () async {
              await NativeChannel.requestPhonePermission();
              await _refreshNetwork();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _gold,
              foregroundColor: Colors.black,
            ),
            child: const Text('Signal Ki Ijazat Dein'),
          ),
        ],
      );
    }
    return const Text(
      'Signal maloom nahi',
      style: TextStyle(color: Colors.white70, fontSize: 14),
    );
  }

  Widget _honestyCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF8E1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _gold),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline, color: Color(0xFF8D6E00)),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Ye app signal nahi barhati — ye aap ko asal signal, asal '
              'speed aur sahi settings tak pohchati hai. Jo number yahan '
              'dikhta hai, woh phone ki asal measurement hai.',
              style: TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _speedCard() {
    final children = <Widget>[];
    if (_speedTesting) {
      final mb = (_speedBytes / 1000000).toStringAsFixed(1);
      children.add(Text('Download ho raha hai: $mb MB / 5.0 MB'));
      children.add(const SizedBox(height: 8));
      children.add(
        LinearProgressIndicator(
          value: (_speedBytes / _speedTotalBytes).clamp(0.0, 1.0),
          color: _green,
        ),
      );
      children.add(const SizedBox(height: 12));
    }
    final r = _speedResult;
    if (r != null) {
      if (r.ok) {
        children.add(_row('Download speed', formatMbps(r.mbps)));
        children.add(_row('Ping', '${r.pingMs} ms'));
        children.add(_row('Test kis par hua', _speedNetworkLabel ?? '—'));
      } else {
        children.add(
          Text(
            r.error ?? 'Speed test nahi ho saka',
            style: const TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.w600,
            ),
          ),
        );
      }
      children.add(const SizedBox(height: 12));
    }
    children.add(
      _bigButton(
        label: _speedTesting ? 'Test chal raha hai…' : 'Speed Test Karein',
        icon: Icons.speed,
        onPressed: _speedTesting ? null : _runSpeedTest,
      ),
    );
    children.add(const SizedBox(height: 6));
    children.add(
      const Text(
        'Asal download naap kar speed nikali jati hai — ek test mein '
        'taqreeban 5 MB data kharch hota hai.',
        style: _noteStyle,
      ),
    );
    return _card(title: 'Asal Speed Test', icon: Icons.speed, children: children);
  }

  Widget _displayCard() {
    final children = <Widget>[];
    final d = _display;
    if (d == null) {
      children.add(const Text('Parh raha hai…'));
    } else if (!d.isAvailable) {
      children.add(const Text('Display ki maloomat nahi mil sakin'));
    } else {
      final rates = uniqueSortedRates(d.supportedHz);
      final max = maxRefreshRate(rates);
      final has120 = supportsRefreshRate(rates, 120);
      children.add(_row('Abhi chal raha hai', formatHz(d.currentHz)));
      if (max != null) {
        children.add(_row('Zyada se zyada speed', formatHz(max)));
      }
      if (rates.isNotEmpty) {
        children.add(_row('Support wale rates', rates.map(formatHz).join(', ')));
      }
      children.add(const SizedBox(height: 8));
      children.add(
        Text(
          has120
              ? 'Is phone par 120 Hz support hai'
              : 'Is phone par 120 Hz support nahi — 90 Hz hi is ki full '
                  'speed hai',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      );
    }
    children.add(const SizedBox(height: 12));
    children.add(
      _bigButton(
        label: 'Display Speed Setting Kholein',
        icon: Icons.display_settings,
        onPressed: () => _openSetting(NativeChannel.openDisplaySettings),
      ),
    );
    children.add(const SizedBox(height: 6));
    children.add(
      const Text(
        'App khud Hz change nahi karti — system kisi app ko ye ijazat '
        'nahi deta. Setting mein ja kar zyada se zyada Hz khud select '
        'karein.',
        style: _noteStyle,
      ),
    );
    return _card(
      title: 'Display — Refresh Rate',
      icon: Icons.monitor,
      children: children,
    );
  }

  String _chargingText(BatteryInfo b) {
    if (b.isCharging) {
      final w = b.chargingW;
      if (w == null) {
        return 'Charging ho rahi hai — power ki asal maloomat nahi mil saki';
      }
      if (isFastCharging(w)) {
        return 'Charging ho rahi hai — taqreeban ${formatWatts(w)} — '
            'Fast charging chal rahi hai';
      }
      return 'Charging ho rahi hai — taqreeban ${formatWatts(w)} — '
          'Slow charging: asal Warp charger aur cable istemal karein '
          '(30W tak milegi)';
    }
    if (b.plugged) {
      return 'Charger laga hai — battery full hai ya charging ruki hui hai';
    }
    return 'Charger nahi laga';
  }

  Widget _batteryCard() {
    final children = <Widget>[];
    final b = _battery;
    if (b == null) {
      children.add(const Text('Parh raha hai…'));
    } else {
      children.add(
        _row('Level', b.levelPct >= 0 ? '${b.levelPct}%' : 'Maloom nahi'),
      );
      children.add(_row('Haalat', batteryHealthLabel(b.healthCode)));
      children.add(
        _row(
          'Temperature',
          b.tempC != null
              ? '${b.tempC!.toStringAsFixed(1)} °C'
              : 'Maloom nahi',
        ),
      );
      children.add(
        _row(
          'Voltage',
          b.voltageV != null
              ? '${b.voltageV!.toStringAsFixed(2)} V'
              : 'Maloom nahi',
        ),
      );
      children.add(
        _row(
          'Charge cycles',
          b.cycleCount >= 0
              ? '${b.cycleCount}'
              : 'Maloom nahi — ye phone ye maloomat nahi deta',
        ),
      );
      children.add(const SizedBox(height: 8));
      children.add(
        Text(
          _chargingText(b),
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
      );
    }
    children.add(const SizedBox(height: 12));
    children.add(
      _bigButton(
        label: 'Battery Setting Kholein',
        icon: Icons.battery_std,
        onPressed: () => _openSetting(NativeChannel.openBatterySettings),
      ),
    );
    return _card(title: 'Battery', icon: Icons.battery_full, children: children);
  }

  Widget _batteryBachaoCard() {
    final children = <Widget>[
      _bigButton(
        label: 'Battery Saver Setting Kholein',
        icon: Icons.battery_saver,
        onPressed: () => _openSetting(NativeChannel.openBatterySaverSettings),
      ),
      const SizedBox(height: 6),
      const Text(
        'Battery Saver on karne se peeche (background) chalti apps ruk '
        'jati hain aur battery zyada der chalti hai. Ye Android ki asal '
        'setting hai — koi jhoota "battery boost" nahi.',
        style: _noteStyle,
      ),
      const Divider(height: 28),
      const Text(
        'Battery aur data khane wali apps — asal list',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
      ),
      const SizedBox(height: 8),
    ];
    if (!_usageGranted) {
      children.add(
        const Text(
          "'Usage access' ki ijazat ke baghair ye list nahi ban sakti. "
          'Ye ijazat app khud nahi le sakti — neeche wale button se '
          'system setting khulegi, wahan "5G Speed Master" ko ijazat '
          'dein.',
          style: _noteStyle,
        ),
      );
      children.add(const SizedBox(height: 10));
      children.add(
        _bigButton(
          label: 'Usage Access Ki Setting Kholein',
          icon: Icons.lock_open,
          onPressed: () => _openSetting(NativeChannel.openUsageAccessSettings),
        ),
      );
    } else {
      final usage = _usage;
      if (usage == null) {
        children.add(const Text('Parh raha hai…'));
      } else {
        children.add(
          const Text(
            'Sab se zyada istemal (pichhle 7 din)',
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
        );
        if (usage.byTime.isEmpty) {
          children.add(const Text('Is arse mein koi asal record nahi mila'));
        }
        for (final app in usage.byTime) {
          children.add(
            _row(
              app.label.isEmpty ? app.packageName : app.label,
              formatDurationMs(app.foregroundMs),
            ),
          );
        }
        children.add(const SizedBox(height: 12));
        children.add(
          const Text(
            'Sab se zyada data (pichhle 7 din)',
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
        );
        if (usage.byData.isEmpty) {
          children.add(const Text('Is arse mein koi asal record nahi mila'));
        }
        for (final app in usage.byData) {
          children.add(
            _row(
              app.label.isEmpty ? app.packageName : app.label,
              formatBytes(app.dataBytes),
            ),
          );
        }
      }
    }
    return _card(title: 'Battery Bachao', icon: Icons.eco, children: children);
  }

  // ------------------------------------------------------------------
  // Screen
  // ------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('5G Speed Master'),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                'v$kAppVersion',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _bigNetworkCard(),
          const SizedBox(height: 12),
          _honestyCard(),
          const SizedBox(height: 12),
          _card(
            title: '5G Setting',
            icon: Icons.settings,
            children: [
              _bigButton(
                label: '5G Setting Kholein',
                icon: Icons.network_cell,
                onPressed: () =>
                    _openSetting(NativeChannel.openNetworkSettings),
              ),
              const SizedBox(height: 6),
              const Text(
                "Wahan 'Preferred network type' mein 5G select karein. "
                'Phone asal 5G par tabhi jayega jab aap ke ilaqa mein '
                '5G coverage ho.',
                style: _noteStyle,
              ),
            ],
          ),
          const SizedBox(height: 12),
          _card(
            title: 'Network Refresh',
            icon: Icons.airplanemode_active,
            children: [
              _bigButton(
                label: 'Network Refresh',
                icon: Icons.airplanemode_active,
                onPressed: () =>
                    _openSetting(NativeChannel.openAirplaneModeSettings),
              ),
              const SizedBox(height: 6),
              const Text(
                'Airplane mode ek dafa on phir off karne se phone '
                'network dobara dhoondta hai aur qareebi 5G cell pakad '
                'sakta hai. Ye asal tareeqa hai — koi "signal boost" '
                'nahi hota.',
                style: _noteStyle,
              ),
            ],
          ),
          const SizedBox(height: 12),
          _card(
            title: '5G Scanner',
            icon: Icons.radar,
            children: [
              _bigButton(
                label: '5G Scanner Kholein',
                icon: Icons.radar,
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const ScannerScreen(),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Is jagah ki asal haalat aur "Jahan 5G Mila" ki list — '
                'jab bhi app khuli ho aur phone asal 5G par ho, woh '
                'jagah khud mehfooz ho jati hai.',
                style: _noteStyle,
              ),
            ],
          ),
          const SizedBox(height: 12),
          _speedCard(),
          const SizedBox(height: 12),
          _displayCard(),
          const SizedBox(height: 12),
          _batteryCard(),
          const SizedBox(height: 12),
          _batteryBachaoCard(),
          const SizedBox(height: 16),
          const Center(
            child: Text(
              '5G Speed Master v$kAppVersion — Bozdar',
              style: TextStyle(color: Colors.black38, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
