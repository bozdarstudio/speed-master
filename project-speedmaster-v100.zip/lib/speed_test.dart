import 'dart:async';
import 'dart:io';

import 'logic.dart';

/// Asal speed test ka natija. [ok] false ho to [error] mein saaf
/// Roman Urdu wajah hoti hai — jhooti speed kabhi nahi dikhti.
class SpeedTestResult {
  const SpeedTestResult({
    required this.ok,
    required this.mbps,
    required this.pingMs,
    required this.bytesDownloaded,
    required this.error,
  });

  final bool ok;
  final double mbps;
  final int pingMs;
  final int bytesDownloaded;
  final String? error;

  factory SpeedTestResult.success({
    required double mbps,
    required int pingMs,
    required int bytes,
  }) =>
      SpeedTestResult(
        ok: true,
        mbps: mbps,
        pingMs: pingMs,
        bytesDownloaded: bytes,
        error: null,
      );

  factory SpeedTestResult.failure(String message) => SpeedTestResult(
        ok: false,
        mbps: 0,
        pingMs: 0,
        bytesDownloaded: 0,
        error: message,
      );
}

/// Asal download speed test — Cloudflare ke public speed endpoint se
/// asal bytes download karke waqt naapta hai (dart:io HttpClient).
///
/// Endpoint: https://speed.cloudflare.com/__down?bytes=N
/// Ek run mein zyada se zyada ~5 MB download hota hai.
class SpeedTestService {
  static const String _base = 'https://speed.cloudflare.com/__down';

  /// Speed test chalao. [onProgress] par ab tak download hue bytes
  /// aate hain (progress dikhane ke liye).
  Future<SpeedTestResult> run({
    int downloadBytes = 5000000,
    void Function(int bytesSoFar)? onProgress,
  }) async {
    final client = HttpClient();
    client.connectionTimeout = const Duration(seconds: 10);
    try {
      // Ping: sab se chhoti request ka asal round-trip waqt.
      final pingWatch = Stopwatch()..start();
      final pingRequest = await client
          .getUrl(Uri.parse('$_base?bytes=0'))
          .timeout(const Duration(seconds: 10));
      final pingResponse =
          await pingRequest.close().timeout(const Duration(seconds: 10));
      await pingResponse.drain<void>();
      pingWatch.stop();
      final pingMs = pingWatch.elapsedMilliseconds;

      // Download: asal bytes gin kar waqt naapo.
      final dlWatch = Stopwatch()..start();
      final request = await client
          .getUrl(Uri.parse('$_base?bytes=$downloadBytes'))
          .timeout(const Duration(seconds: 10));
      final response =
          await request.close().timeout(const Duration(seconds: 10));
      if (response.statusCode != HttpStatus.ok) {
        return SpeedTestResult.failure(
          'Speed test nahi ho saka — server ne jawab nahi diya '
          '(${response.statusCode})',
        );
      }
      var received = 0;
      await for (final chunk
          in response.timeout(const Duration(seconds: 30))) {
        received += chunk.length;
        onProgress?.call(received);
      }
      dlWatch.stop();
      if (received <= 0) {
        return SpeedTestResult.failure(
          'Speed test nahi ho saka — internet check karein',
        );
      }
      return SpeedTestResult.success(
        mbps: mbpsFromBytes(received, dlWatch.elapsed),
        pingMs: pingMs,
        bytes: received,
      );
    } on SocketException {
      return SpeedTestResult.failure(
        'Speed test nahi ho saka — internet check karein',
      );
    } on TimeoutException {
      return SpeedTestResult.failure(
        'Speed test nahi ho saka — internet bohat slow ya band hai',
      );
    } on HandshakeException {
      return SpeedTestResult.failure(
        'Speed test nahi ho saka — internet check karein',
      );
    } catch (_) {
      return SpeedTestResult.failure(
        'Speed test nahi ho saka — internet check karein',
      );
    } finally {
      client.close(force: true);
    }
  }
}
