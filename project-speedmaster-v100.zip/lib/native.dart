import 'package:flutter/services.dart';

import 'logic.dart';

/// Native Android (Kotlin) se baat — TelephonyManager, Display,
/// BatteryManager aur UsageStatsManager ki ASAL maloomat.
///
/// Channel: `com.bozdar.speedmaster/native`
///
/// HONESTY LOCK: har value device se asal parhi jati hai. Jo cheez na
/// mil sake (permission na ho, platform na de) wahan null / 'maloom
/// nahi' aata hai — koi andaza ya bana hua number kabhi nahi.

class NetworkInfo {
  const NetworkInfo({
    required this.permissionGranted,
    required this.operatorName,
    required this.dataNetworkType,
    required this.overrideNetworkType,
    required this.hasCellService,
    required this.signalDbm,
    required this.isWifiConnected,
  });

  /// READ_PHONE_STATE ki ijazat mili hui hai ya nahi.
  final bool permissionGranted;

  /// Operator ka naam ('' = maloom nahi).
  final String operatorName;

  /// TelephonyManager ka data network type (0 = UNKNOWN).
  final int dataNetworkType;

  /// TelephonyDisplayInfo ka override type (NSA 5G pehchan ke liye).
  final int overrideNetworkType;

  /// Mobile service mojood hai ya nahi (ServiceState se).
  final bool hasCellService;

  /// Signal ki asal taqat dBm mein; null = maloom nahi / ijazat nahi.
  final int? signalDbm;

  /// Wi-Fi se juda hai ya nahi (ConnectivityManager se).
  final bool isWifiConnected;

  factory NetworkInfo.unavailable() => const NetworkInfo(
        permissionGranted: false,
        operatorName: '',
        dataNetworkType: 0,
        overrideNetworkType: 0,
        hasCellService: false,
        signalDbm: null,
        isWifiConnected: false,
      );

  factory NetworkInfo.fromMap(Map<dynamic, dynamic> map) {
    return NetworkInfo(
      permissionGranted: map['permissionGranted'] as bool? ?? false,
      operatorName: map['operatorName'] as String? ?? '',
      dataNetworkType: (map['dataNetworkType'] as num?)?.toInt() ?? 0,
      overrideNetworkType: (map['overrideNetworkType'] as num?)?.toInt() ?? 0,
      hasCellService: map['hasCellService'] as bool? ?? false,
      signalDbm: (map['signalDbm'] as num?)?.toInt(),
      isWifiConnected: map['isWifiConnected'] as bool? ?? false,
    );
  }

  /// '5G' / '4G' / '3G' / '2G' / 'Wi-Fi' / 'Koi network nahi' / 'Maloom nahi'
  String get typeLabel => networkTypeLabel(
        dataNetworkType: dataNetworkType,
        overrideNetworkType: overrideNetworkType,
        isWifiConnected: isWifiConnected,
        hasCellService: hasCellService,
      );
}

class DisplayInfo {
  const DisplayInfo({required this.currentHz, required this.supportedHz});

  /// Abhi chal raha refresh rate (Hz); 0 = maloom nahi.
  final double currentHz;

  /// Device ke asal supported rates (Hz) — khud device se parhe hue.
  final List<double> supportedHz;

  factory DisplayInfo.unavailable() =>
      const DisplayInfo(currentHz: 0, supportedHz: []);

  factory DisplayInfo.fromMap(Map<dynamic, dynamic> map) {
    final raw = (map['supportedHz'] as List?) ?? const [];
    return DisplayInfo(
      currentHz: (map['currentHz'] as num?)?.toDouble() ?? 0,
      supportedHz: raw.whereType<num>().map((e) => e.toDouble()).toList(),
    );
  }

  bool get isAvailable => currentHz > 0 || supportedHz.isNotEmpty;
}

class BatteryInfo {
  const BatteryInfo({
    required this.levelPct,
    required this.healthCode,
    required this.tempC,
    required this.voltageV,
    required this.cycleCount,
    required this.plugged,
    required this.isCharging,
    required this.currentMicroAmps,
  });

  /// Battery level % mein; -1 = maloom nahi.
  final int levelPct;

  /// BatteryManager ka health code (2 = GOOD).
  final int healthCode;

  /// Temperature °C mein; null = maloom nahi.
  final double? tempC;

  /// Voltage V mein; null = maloom nahi.
  final double? voltageV;

  /// Charge cycles; -1 = ye platform nahi deta.
  final int cycleCount;

  /// Charger laga hua hai ya nahi.
  final bool plugged;

  /// Battery charge ho rahi hai (ya full) ya nahi.
  final bool isCharging;

  /// Is waqt ka current (micro-amp); null = platform ne nahi diya.
  final int? currentMicroAmps;

  factory BatteryInfo.unavailable() => const BatteryInfo(
        levelPct: -1,
        healthCode: 1,
        tempC: null,
        voltageV: null,
        cycleCount: -1,
        plugged: false,
        isCharging: false,
        currentMicroAmps: null,
      );

  factory BatteryInfo.fromMap(Map<dynamic, dynamic> map) {
    return BatteryInfo(
      levelPct: (map['levelPct'] as num?)?.toInt() ?? -1,
      healthCode: (map['healthCode'] as num?)?.toInt() ?? 1,
      tempC: (map['tempC'] as num?)?.toDouble(),
      voltageV: (map['voltageV'] as num?)?.toDouble(),
      cycleCount: (map['cycleCount'] as num?)?.toInt() ?? -1,
      plugged: map['plugged'] as bool? ?? false,
      isCharging: map['isCharging'] as bool? ?? false,
      currentMicroAmps: (map['currentUa'] as num?)?.toInt(),
    );
  }

  /// Taqreeban charging watts — sirf jab charge ho raha ho aur current
  /// aur voltage dono asal mile hon; warna null (jhoota number nahi).
  double? get chargingW {
    final ua = currentMicroAmps;
    final v = voltageV;
    if (!isCharging || ua == null || v == null) return null;
    return chargingWatts(currentMicroAmps: ua, voltageVolts: v);
  }
}

/// Ek top app — UsageStatsManager / NetworkStatsManager ka asal record.
class TopAppUsage {
  const TopAppUsage({
    required this.packageName,
    required this.label,
    required this.foregroundMs,
    required this.dataBytes,
  });

  final String packageName;
  final String label;

  /// Pichhle 7 din ka foreground istemal (ms); -1 = is metric mein nahi.
  final int foregroundMs;

  /// Pichhle 7 din ka mobile + Wi-Fi data (bytes); -1 = is metric mein nahi.
  final int dataBytes;
}

class UsageTopApps {
  const UsageTopApps({
    required this.granted,
    required this.byTime,
    required this.byData,
  });

  /// Usage access ki ijazat mili hui hai ya nahi.
  final bool granted;

  /// Foreground waqt ke hisaab se top apps (zyada se kam).
  final List<TopAppUsage> byTime;

  /// Data kharch ke hisaab se top apps (zyada se kam).
  final List<TopAppUsage> byData;

  factory UsageTopApps.notGranted() =>
      const UsageTopApps(granted: false, byTime: [], byData: []);

  factory UsageTopApps.fromMap(Map<dynamic, dynamic> map) {
    TopAppUsage parse(Map<dynamic, dynamic> m, {required bool isTime}) {
      return TopAppUsage(
        packageName: m['packageName'] as String? ?? '',
        label: m['label'] as String? ?? '',
        foregroundMs:
            isTime ? ((m['foregroundMs'] as num?)?.toInt() ?? 0) : -1,
        dataBytes: isTime ? -1 : ((m['totalBytes'] as num?)?.toInt() ?? 0),
      );
    }

    final timeRaw = (map['byTime'] as List?) ?? const [];
    final dataRaw = (map['byData'] as List?) ?? const [];
    return UsageTopApps(
      granted: map['granted'] as bool? ?? false,
      byTime: timeRaw
          .whereType<Map<dynamic, dynamic>>()
          .map((m) => parse(m, isTime: true))
          .toList(),
      byData: dataRaw
          .whereType<Map<dynamic, dynamic>>()
          .map((m) => parse(m, isTime: false))
          .toList(),
    );
  }
}

/// LocationManager se asal location (sirf tab jab runtime ijazat mili
/// ho). Ijazat na ho to [granted] false aur coordinates null rehte
/// hain — app "jagah maloom nahi" hi likhti hai, andaza NAHI lagati.
class LocationInfo {
  const LocationInfo({
    required this.granted,
    required this.lat,
    required this.lng,
    required this.area,
  });

  final bool granted;
  final double? lat;
  final double? lng;

  /// Geocoder se area/ilaqe ka naam; na mile to khaali.
  final String area;

  factory LocationInfo.notGranted() => const LocationInfo(
        granted: false,
        lat: null,
        lng: null,
        area: '',
      );

  factory LocationInfo.fromMap(Map<dynamic, dynamic> map) => LocationInfo(
        granted: map['granted'] as bool? ?? false,
        lat: (map['lat'] as num?)?.toDouble(),
        lng: (map['lng'] as num?)?.toDouble(),
        area: map['area'] as String? ?? '',
      );
}

class NativeChannel {
  static const _channel = MethodChannel('com.bozdar.speedmaster/native');

  /// Live network ki asal haalat. Ghalti par unavailable (UI saaf
  /// 'maloom nahi' dikhayegi, jhoota number nahi).
  static Future<NetworkInfo> getNetworkInfo() async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getNetworkInfo',
      );
      if (result == null) return NetworkInfo.unavailable();
      return NetworkInfo.fromMap(result);
    } on PlatformException {
      return NetworkInfo.unavailable();
    } on MissingPluginException {
      return NetworkInfo.unavailable();
    }
  }

  /// READ_PHONE_STATE ki runtime ijazat mango. Jawab: mili ya nahi.
  static Future<bool> requestPhonePermission() async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'requestPhonePermission',
      );
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// 5G / network operator ki system setting kholo (fallbacks native
  /// taraf hain: NETWORK_OPERATOR_SETTINGS → WIRELESS → SETTINGS).
  static Future<bool> openNetworkSettings() => _open('openNetworkSettings');

  /// Airplane mode ki system setting kholo — "Network Refresh":
  /// airplane mode on/off karne se phone network dobara dhoondta hai.
  /// (Ye koi signal boost NAHI hai — sirf asal system setting hai.)
  static Future<bool> openAirplaneModeSettings() =>
      _open('openAirplaneModeSettings');

  /// Display (refresh rate) ki system setting kholo.
  static Future<bool> openDisplaySettings() => _open('openDisplaySettings');

  /// Battery Saver ki system setting kholo.
  static Future<bool> openBatterySaverSettings() =>
      _open('openBatterySaverSettings');

  /// Battery usage ki system setting kholo.
  static Future<bool> openBatterySettings() => _open('openBatterySettings');

  /// System ki "Usage access" setting kholo — wahan se user khud is app
  /// ko ijazat deta hai (app khud ye ijazat nahi le sakti).
  static Future<bool> openUsageAccessSettings() =>
      _open('openUsageAccessSettings');

  // ---- 5G Scanner: location, mehfooz jaghein, coverage map ------------

  /// Location ki ijazat mili hui hai ya nahi (sirf check, mangta nahi).
  static Future<bool> hasLocationPermission() async {
    try {
      final result =
          await _channel.invokeMethod<bool>('hasLocationPermission');
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// Location ki runtime ijazat mango. Jawab: mili ya nahi.
  static Future<bool> requestLocationPermission() async {
    try {
      final result =
          await _channel.invokeMethod<bool>('requestLocationPermission');
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// Abhi ki asal location (last-known ya ek fresh fix) + area ka naam.
  /// Ijazat na ho to [LocationInfo.notGranted].
  static Future<LocationInfo> getCurrentLocation() async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getCurrentLocation',
      );
      if (result == null) return LocationInfo.notGranted();
      return LocationInfo.fromMap(result);
    } on PlatformException {
      return LocationInfo.notGranted();
    } on MissingPluginException {
      return LocationInfo.notGranted();
    }
  }

  /// "Jahan 5G Mila" ki mehfooz list (JSON) — storage native
  /// SharedPreferences mein hai, koi plugin nahi.
  static Future<String> readPlacesJson() async {
    try {
      final result = await _channel.invokeMethod<String>('readPlacesJson');
      return result ?? '[]';
    } on PlatformException {
      return '[]';
    } on MissingPluginException {
      return '[]';
    }
  }

  /// List ko wapas SharedPreferences mein mehfooz karta hai.
  static Future<bool> writePlacesJson(String json) async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'writePlacesJson',
        <String, dynamic>{'json': json},
      );
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// Browser mein di hui (official) site kholta hai — coverage map ke
  /// liye. App ke andar koi nakli map NAHI banta.
  static Future<bool> openCoverageMap(String url) async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'openCoverageMap',
        <String, dynamic>{'url': url},
      );
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  static Future<bool> _open(String method) async {
    try {
      final result = await _channel.invokeMethod<bool>(method);
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// Display ke asal supported refresh rates + abhi wala rate.
  static Future<DisplayInfo> getDisplayInfo() async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getDisplayInfo',
      );
      if (result == null) return DisplayInfo.unavailable();
      return DisplayInfo.fromMap(result);
    } on PlatformException {
      return DisplayInfo.unavailable();
    } on MissingPluginException {
      return DisplayInfo.unavailable();
    }
  }

  /// Battery ki asal haalat.
  static Future<BatteryInfo> getBatteryInfo() async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getBatteryInfo',
      );
      if (result == null) return BatteryInfo.unavailable();
      return BatteryInfo.fromMap(result);
    } on PlatformException {
      return BatteryInfo.unavailable();
    } on MissingPluginException {
      return BatteryInfo.unavailable();
    }
  }

  /// "Battery Bachao": Usage access hai ya nahi.
  static Future<bool> hasUsageAccess() async {
    try {
      final result = await _channel.invokeMethod<bool>('hasUsageAccess');
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// Pichhle 7 din ki asal top apps (foreground waqt + data kharch).
  /// Ijazat na ho to granted=false wapas aata hai — list nahi banti.
  static Future<UsageTopApps> getUsageTopApps() async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getUsageTopApps',
      );
      if (result == null) return UsageTopApps.notGranted();
      return UsageTopApps.fromMap(result);
    } on PlatformException {
      return UsageTopApps.notGranted();
    } on MissingPluginException {
      return UsageTopApps.notGranted();
    }
  }
}
