// Saf (pure) logic — koi platform call nahi, sirf asal numberon ki
// tashreeh. Har function unit test se cover hai.
//
// HONESTY LOCK: yahan koi number BANA nahi jata — jo device deta hai
// sirf usi ki Roman Urdu tashreeh hoti hai.

import 'dart:math' as math;

// ---------------------------------------------------------------------------
// Network type — Android TelephonyManager ke constants:
//   0 UNKNOWN, 1 GPRS, 2 EDGE, 3 UMTS, 4 CDMA, 5 EVDO_0, 6 EVDO_A,
//   7 1xRTT, 8 HSDPA, 9 HSUPA, 10 HSPA, 11 IDEN, 12 EVDO_B, 13 LTE,
//   14 EHRPD, 15 HSPAP, 16 GSM, 17 TD_SCDMA, 18 IWLAN, 19 LTE_CA, 20 NR.
// Override (TelephonyDisplayInfo): 0 NONE, 1 LTE_CA, 2 LTE_ADVANCED_PRO,
//   3 NR_NSA, 4 NR_NSA_MMWAVE, 5 NR_ADVANCED.
// ---------------------------------------------------------------------------

/// Asal network ka label: '5G' / '4G' / '3G' / '2G' / 'Wi-Fi' /
/// 'Koi network nahi' / 'Maloom nahi'.
///
/// 5G do tareeqon se pakra jata hai: data type khud NR (20) ho, ya
/// display override NR_NSA / NR_NSA_MMWAVE / NR_ADVANCED ho (NSA 5G mein
/// data type LTE rehta hai lekin phone 5G se juda hota hai).
String networkTypeLabel({
  required int dataNetworkType,
  required int overrideNetworkType,
  required bool isWifiConnected,
  required bool hasCellService,
}) {
  if (isWifiConnected) return 'Wi-Fi';
  if (dataNetworkType == 20 ||
      overrideNetworkType == 3 ||
      overrideNetworkType == 4 ||
      overrideNetworkType == 5) {
    return '5G';
  }
  switch (dataNetworkType) {
    case 13: // LTE
    case 19: // LTE_CA
      return '4G';
    case 3: // UMTS
    case 5: // EVDO_0
    case 6: // EVDO_A
    case 8: // HSDPA
    case 9: // HSUPA
    case 10: // HSPA
    case 12: // EVDO_B
    case 14: // EHRPD
    case 15: // HSPAP
    case 17: // TD_SCDMA
      return '3G';
    case 1: // GPRS
    case 2: // EDGE
    case 4: // CDMA
    case 7: // 1xRTT
    case 11: // IDEN
    case 16: // GSM
      return '2G';
    default:
      // Type maloom nahi — service hai to 'Maloom nahi', warna saaf
      // 'Koi network nahi'. Jhoota label kabhi nahi.
      return hasCellService ? 'Maloom nahi' : 'Koi network nahi';
  }
}

// ---------------------------------------------------------------------------
// Signal quality — dBm se level (0–4) aur Roman Urdu lafz.
// Haddain aam radio practice par hain:
//   >= -70 bohat acha, >= -85 acha, >= -100 darmiyana,
//   >= -110 kamzor, us se neeche bohat kamzor.
// ---------------------------------------------------------------------------

class SignalQuality {
  const SignalQuality(this.level, this.word);

  /// 0 = sab se kamzor, 4 = sab se mazboot.
  final int level;
  final String word;
}

SignalQuality signalQuality(int dbm) {
  if (dbm >= -70) return const SignalQuality(4, 'Bohat acha');
  if (dbm >= -85) return const SignalQuality(3, 'Acha');
  if (dbm >= -100) return const SignalQuality(2, 'Darmiyana');
  if (dbm >= -110) return const SignalQuality(1, 'Kamzor');
  return const SignalQuality(0, 'Bohat kamzor');
}

// ---------------------------------------------------------------------------
// Speed — asal download measurement ki hisaab kitab.
// ---------------------------------------------------------------------------

/// Bytes aur waqt se Mbps (megabits per second) nikalo.
double mbpsFromBytes(int bytes, Duration elapsed) {
  final micros = elapsed.inMicroseconds;
  if (bytes <= 0 || micros <= 0) return 0;
  final seconds = micros / Duration.microsecondsPerSecond;
  return (bytes * 8) / seconds / 1000000;
}

/// Mbps ki saf numaish: 100+ par baghair decimal, warna 1 decimal.
String formatMbps(double mbps) {
  if (mbps >= 100) return '${mbps.toStringAsFixed(0)} Mbps';
  return '${mbps.toStringAsFixed(1)} Mbps';
}

// ---------------------------------------------------------------------------
// Battery — Android BatteryManager ke health codes:
//   1 UNKNOWN, 2 GOOD, 3 OVERHEAT, 4 DEAD, 5 OVER_VOLTAGE,
//   6 UNSPECIFIED_FAILURE, 7 COLD.
// ---------------------------------------------------------------------------

String batteryHealthLabel(int healthCode) {
  switch (healthCode) {
    case 2:
      return 'Achi haalat';
    case 3:
      return 'Battery garam hai';
    case 4:
      return 'Battery kharab hai';
    case 5:
      return 'Voltage zyada hai';
    case 6:
      return 'Battery mein masla hai';
    case 7:
      return 'Battery thandi hai';
    default:
      return 'Maloom nahi';
  }
}

/// Charging power ka taqreeban hisaab: current (micro-amp) x voltage.
/// Android ka current sign mukhtalif devices par ulta bhi ho sakta hai,
/// is liye absolute value — ye taqreeban (approximate) number hai,
/// UI mein bhi "taqreeban" likha jata hai.
double chargingWatts({
  required int currentMicroAmps,
  required double voltageVolts,
}) {
  return currentMicroAmps.abs() / 1000000.0 * voltageVolts;
}

/// 15W ya zyada = fast charging (aam usool).
bool isFastCharging(double watts) => watts >= 15.0;

String formatWatts(double watts) => '${watts.toStringAsFixed(1)} W';

// ---------------------------------------------------------------------------
// Display refresh rate — Display ke asal supported modes se hisaab.
// Koi rate HARDCODE nahi hota: 120 support hai ya nahi, ye sirf asal
// list se pata chalta hai.
// ---------------------------------------------------------------------------

/// Kya [target] Hz asal supported list mein hai? (0.5 Hz tolerance —
/// kuch devices 119.98 jaisi value dete hain.)
bool supportsRefreshRate(List<double> supportedRates, double target) {
  return supportedRates.any((r) => (r - target).abs() < 0.5);
}

/// Zyada se zyada supported rate; khaali list par null.
double? maxRefreshRate(List<double> supportedRates) {
  if (supportedRates.isEmpty) return null;
  var best = supportedRates.first;
  for (final r in supportedRates) {
    if (r > best) best = r;
  }
  return best;
}

/// Duplicate hata kar chhote se bara tartib.
List<double> uniqueSortedRates(List<double> rates) {
  final seen = <int>{};
  final out = <double>[];
  for (final r in rates) {
    final key = (r * 10).round(); // 0.1 Hz ki darusti par dedupe
    if (seen.add(key)) out.add(r);
  }
  out.sort();
  return out;
}

// ---------------------------------------------------------------------------
// "Battery Bachao" — UsageStats ke asal numberon ki numaish.
// ---------------------------------------------------------------------------

/// Foreground istemal ka waqt Roman Urdu mein:
/// 7_500_000 ms -> '2 ghante 5 minute', 2_700_000 ms -> '45 minute',
/// 30_000 ms -> '1 minute se kam'.
String formatDurationMs(int millis) {
  if (millis < 60000) return '1 minute se kam';
  final totalMinutes = millis ~/ 60000;
  final hours = totalMinutes ~/ 60;
  final minutes = totalMinutes % 60;
  if (hours <= 0) return '$minutes minute';
  if (minutes == 0) return '$hours ghante';
  return '$hours ghante $minutes minute';
}

/// Data ka size asal hisaab se: bytes -> '850 KB' / '350 MB' / '1.2 GB'.
String formatBytes(int bytes) {
  if (bytes < 1024) return '$bytes B';
  final kb = bytes / 1024;
  if (kb < 1024) return '${kb.toStringAsFixed(0)} KB';
  final mb = kb / 1024;
  if (mb < 1024) return '${mb.toStringAsFixed(0)} MB';
  final gb = mb / 1024;
  return '${gb.toStringAsFixed(1)} GB';
}

/// Refresh rate ki numaish: poora number ho to baghair decimal
/// (90.0 -> '90 Hz'), warna 1 decimal (119.98 -> '120.0 Hz').
String formatHz(double hz) {
  if (hz == hz.roundToDouble()) return '${hz.round()} Hz';
  return '${hz.toStringAsFixed(1)} Hz';
}

// ---------------------------------------------------------------------------
// 5G Scanner — jagah aur waqt ke asal hisaab.
// ---------------------------------------------------------------------------

double _toRad(double deg) => deg * math.pi / 180.0;

/// Do coordinates ke darmiyan asal faasla (meters) — Haversine.
/// "Jahan 5G Mila" ki duplicate entry rokne ke liye istemal hota hai.
double distanceMeters(double lat1, double lng1, double lat2, double lng2) {
  const earthRadius = 6371000.0;
  final dLat = _toRad(lat2 - lat1);
  final dLng = _toRad(lng2 - lng1);
  final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(_toRad(lat1)) *
          math.cos(_toRad(lat2)) *
          math.sin(dLng / 2) *
          math.sin(dLng / 2);
  final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  return earthRadius * c;
}

/// Waqt ki numaish: '12 Nov 2026, 3:45 PM' (device ke local waqt par).
String formatDateTime(int epochMs) {
  final dt = DateTime.fromMillisecondsSinceEpoch(epochMs);
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  var hour = dt.hour % 12;
  if (hour == 0) hour = 12;
  final ampm = dt.hour < 12 ? 'AM' : 'PM';
  final minute = dt.minute.toString().padLeft(2, '0');
  return '${dt.day} ${months[dt.month - 1]} ${dt.year}, $hour:$minute $ampm';
}

/// Operator ke naam se us ki OFFICIAL website — coverage map wahan
/// milta hai. Koi bana hua (fake) map app ke andar NAHI hai; browser
/// mein operator ki apni site khulti hai. Naam na pehchana jaye to
/// PTA (regulator) ki site.
String coverageUrlForOperator(String operatorName) {
  final n = operatorName.toLowerCase();
  if (n.contains('jazz')) return 'https://www.jazz.com.pk';
  if (n.contains('zong')) return 'https://www.zong.com.pk';
  if (n.contains('ufone')) return 'https://www.ufone.com';
  if (n.contains('telenor')) return 'https://www.telenor.com.pk';
  return 'https://www.pta.gov.pk';
}
