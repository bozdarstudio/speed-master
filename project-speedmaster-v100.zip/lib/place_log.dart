import 'dart:convert';

import 'logic.dart';
import 'native.dart';

/// "Jahan 5G Mila" ki ek asal entry — sirf tab banti hai jab phone
/// ASAL mein NR (5G) par ho aur app khuli ho. Koi andaza, koi nakli
/// jagah kabhi nahi.
class PlaceEntry {
  const PlaceEntry({
    required this.timeMs,
    required this.dbm,
    required this.lat,
    required this.lng,
    required this.area,
  });

  /// Entry ka waqt (epoch milliseconds).
  final int timeMs;

  /// Us lamhe ka asal signal (dBm); permission na ho to null.
  final int? dbm;

  /// Location ki ijazat mili ho to asal coordinates, warna null.
  final double? lat;
  final double? lng;

  /// Geocoder se area ka naam; na mile / ijazat na ho to khaali.
  final String area;

  Map<String, dynamic> toJson() => <String, dynamic>{
        't': timeMs,
        'dbm': dbm,
        'lat': lat,
        'lng': lng,
        'area': area,
      };

  factory PlaceEntry.fromJson(Map<String, dynamic> json) => PlaceEntry(
        timeMs: (json['t'] as num?)?.toInt() ?? 0,
        dbm: (json['dbm'] as num?)?.toInt(),
        lat: (json['lat'] as num?)?.toDouble(),
        lng: (json['lng'] as num?)?.toDouble(),
        area: json['area'] as String? ?? '',
      );
}

/// 5G wali jagahon ka record — storage Android SharedPreferences mein
/// (native channel ke zariye), taake koi heavy plugin na lage.
///
/// Duplicate/rakar rokne ka usool: nayi entry tabhi banti hai jab
///  - pichli entry ko 30 minute se zyada ho gaye hon, YA
///  - jagah asal mein badal gayi ho (coordinates se 300 meter se
///    zyada faasla).
/// Dono taraf coordinates na hon to 30 minute ke andar doosri entry
/// NAHI banti.
class FiveGPlaceLog {
  static const int minGapMs = 30 * 60 * 1000;
  static const double minMoveMeters = 300;
  static const int maxEntries = 100;
  static bool _busy = false;

  /// Mehfooz entries parhta hai (purani se nayi ki taraf).
  static Future<List<PlaceEntry>> load() async {
    final raw = await NativeChannel.readPlacesJson();
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        return decoded
            .whereType<Map<String, dynamic>>()
            .map(PlaceEntry.fromJson)
            .toList();
      }
    } catch (_) {
      // Kharab data ho to khaali list — app rukti NAHI hai.
    }
    return <PlaceEntry>[];
  }

  /// Agar phone is waqt ASAL 5G par hai to (usool ke mutabiq) ek
  /// entry mehfooz karta hai. Location sirf tab jati hai jab ijazat
  /// pehle se mili ho — ye function khamoshi se chalta hai, recording
  /// ke liye permission NAHI mangta.
  static Future<void> maybeRecord(NetworkInfo net) async {
    if (net.typeLabel != '5G' || _busy) return;
    _busy = true;
    try {
      final places = await load();
      final now = DateTime.now().millisecondsSinceEpoch;
      final last = places.isEmpty ? null : places.last;
      if (last != null && now - last.timeMs < minGapMs) {
        // 30 minute ke andar: sirf tab aage barho jab pichli entry ke
        // paas coordinates hon aur nayi jagah asal mein door ho.
        if (last.lat == null || last.lng == null) return;
        final probe = await NativeChannel.getCurrentLocation();
        if (probe.lat == null || probe.lng == null) return;
        if (distanceMeters(last.lat!, last.lng!, probe.lat!, probe.lng!) <
            minMoveMeters) {
          return; // wohi jagah hai — duplicate NAHI.
        }
        places.add(PlaceEntry(
          timeMs: now,
          dbm: net.signalDbm,
          lat: probe.lat,
          lng: probe.lng,
          area: probe.area,
        ));
      } else {
        final loc = await NativeChannel.getCurrentLocation();
        places.add(PlaceEntry(
          timeMs: now,
          dbm: net.signalDbm,
          lat: loc.lat,
          lng: loc.lng,
          area: loc.area,
        ));
      }
      final trimmed = places.length > maxEntries
          ? places.sublist(places.length - maxEntries)
          : places;
      await NativeChannel.writePlacesJson(
        jsonEncode(trimmed.map((e) => e.toJson()).toList()),
      );
    } catch (_) {
      // Recording fail ho jaye to app ka asal kaam rukta NAHI hai.
    } finally {
      _busy = false;
    }
  }
}
