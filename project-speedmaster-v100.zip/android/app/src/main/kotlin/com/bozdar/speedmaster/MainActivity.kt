package com.bozdar.speedmaster

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.telephony.CellSignalStrengthLte
import android.telephony.CellSignalStrengthNr
import android.telephony.PhoneStateListener
import android.telephony.ServiceState
import android.telephony.SignalStrength
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Native channel: com.bozdar.speedmaster/native
 *
 * HONESTY LOCK: yahan sirf Android ki ASAL maloomat parhi jati hai —
 * koi signal "barhaya" nahi jata, koi number banaya nahi jata, koi
 * setting zabardasti badli nahi jati. Jo cheez permission ya platform
 * ki wajah se na mil sake, wahan null / khaali wapas jata hai aur Dart
 * taraf saaf "maloom nahi / permission nahi mili" dikhta hai.
 *
 * Methods:
 *  - getNetworkInfo — TelephonyManager se operator, data network type,
 *    TelephonyDisplayInfo se 5G override (NSA pehchan), SignalStrength
 *    se asal dBm, ConnectivityManager se Wi-Fi haalat.
 *  - requestPhonePermission — READ_PHONE_STATE ki runtime ijazat.
 *  - openNetworkSettings / openDisplaySettings /
 *    openBatterySaverSettings / openBatterySettings /
 *    openUsageAccessSettings — system ki asal setting screens (fallbacks
 *    ke saath). App khud koi setting change NAHI karti.
 *  - getDisplayInfo — Display ke asal supported refresh rates.
 *  - getBatteryInfo — BatteryManager + ACTION_BATTERY_CHANGED se asal
 *    level / health / temperature / voltage / cycle / current.
 *  - hasUsageAccess + getUsageTopApps — UsageStatsManager aur
 *    NetworkStatsManager se pichhle 7 din ki asal top apps (sirf jab
 *    user ne system "Usage access" setting se ijazat di ho).
 *  - 5G Scanner: hasLocationPermission / requestLocationPermission —
 *    location ki ijazat ka check/request; getCurrentLocation —
 *    LocationManager se asal fix + Geocoder se area; readPlacesJson /
 *    writePlacesJson — "Jahan 5G Mila" ki list SharedPreferences mein;
 *    openCoverageMap — browser mein operator ki official site.
 */
class MainActivity : FlutterActivity() {
    private val channelName = "com.bozdar.speedmaster/native"
    private val phonePermRequestCode = 4101
    private val locationPermRequestCode = 4102

    private var pendingPermissionResult: MethodChannel.Result? = null
    private var pendingLocationResult: MethodChannel.Result? = null

    // Listener/callback se cache shuda asal telephony haalat.
    @Volatile private var lastOverrideNetworkType: Int = 0
    @Volatile private var lastServiceState: ServiceState? = null
    @Volatile private var lastSignalStrength: SignalStrength? = null

    private var telephonyCallback: TelephonyCallback? = null
    private var phoneStateListener: PhoneStateListener? = null

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        registerTelephonyListeners()
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "getNetworkInfo" -> result.success(getNetworkInfo())
                "requestPhonePermission" -> requestPhonePermission(result)
                "openNetworkSettings" -> result.success(
                    openFirstAvailable(
                        listOf(
                            Settings.ACTION_NETWORK_OPERATOR_SETTINGS,
                            Settings.ACTION_WIRELESS_SETTINGS,
                            Settings.ACTION_SETTINGS
                        )
                    )
                )
                "openAirplaneModeSettings" -> result.success(
                    openFirstAvailable(
                        listOf(
                            Settings.ACTION_AIRPLANE_MODE_SETTINGS,
                            Settings.ACTION_SETTINGS
                        )
                    )
                )
                "openDisplaySettings" -> result.success(
                    openFirstAvailable(
                        listOf(
                            Settings.ACTION_DISPLAY_SETTINGS,
                            Settings.ACTION_SETTINGS
                        )
                    )
                )
                "openBatterySaverSettings" -> result.success(
                    openFirstAvailable(
                        listOf(
                            Settings.ACTION_BATTERY_SAVER_SETTINGS,
                            Settings.ACTION_SETTINGS
                        )
                    )
                )
                "openBatterySettings" -> result.success(
                    openFirstAvailable(
                        listOf(
                            Intent.ACTION_POWER_USAGE_SUMMARY,
                            Settings.ACTION_SETTINGS
                        )
                    )
                )
                "openUsageAccessSettings" -> result.success(
                    openFirstAvailable(
                        listOf(
                            Settings.ACTION_USAGE_ACCESS_SETTINGS,
                            Settings.ACTION_SETTINGS
                        )
                    )
                )
                "getDisplayInfo" -> result.success(getDisplayInfo())
                "getBatteryInfo" -> result.success(getBatteryInfo())
                "hasUsageAccess" -> result.success(hasUsageAccess())
                "getUsageTopApps" -> getUsageTopApps(result)
                "hasLocationPermission" -> result.success(hasLocationPermission())
                "requestLocationPermission" -> requestLocationPermission(result)
                "getCurrentLocation" -> getCurrentLocation(result)
                "readPlacesJson" -> result.success(readPlacesJson())
                "writePlacesJson" -> result.success(
                    writePlacesJson(call.argument<String>("json") ?: "[]")
                )
                "openCoverageMap" -> {
                    val url = call.argument<String>("url")
                    result.success(!url.isNullOrEmpty() && openUrl(url))
                }
                else -> result.notImplemented()
            }
        }
    }

    // ------------------------------------------------------------------
    // Telephony listeners — asal ServiceState / SignalStrength /
    // DisplayInfo (5G override) cache karte hain.
    // ------------------------------------------------------------------

    private fun registerTelephonyListeners() {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (telephonyCallback != null) return
                val cb = object : TelephonyCallback(),
                    TelephonyCallback.DisplayInfoListener,
                    TelephonyCallback.ServiceStateListener,
                    TelephonyCallback.SignalStrengthsListener {
                    override fun onDisplayInfoChanged(info: TelephonyDisplayInfo) {
                        lastOverrideNetworkType = info.overrideNetworkType
                    }

                    override fun onServiceStateChanged(state: ServiceState) {
                        lastServiceState = state
                    }

                    override fun onSignalStrengthsChanged(strength: SignalStrength) {
                        lastSignalStrength = strength
                    }
                }
                telephonyCallback = cb
                tm.registerTelephonyCallback(Executors.newSingleThreadExecutor(), cb)
            } else {
                if (phoneStateListener != null) return
                val listener = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onServiceStateChanged(state: ServiceState?) {
                        lastServiceState = state
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onSignalStrengthsChanged(strength: SignalStrength?) {
                        lastSignalStrength = strength
                    }

                    override fun onDisplayInfoChanged(info: TelephonyDisplayInfo) {
                        lastOverrideNetworkType = info.overrideNetworkType
                    }
                }
                phoneStateListener = listener
                var events = PhoneStateListener.LISTEN_SERVICE_STATE or
                    PhoneStateListener.LISTEN_SIGNAL_STRENGTHS
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    events = events or PhoneStateListener.LISTEN_DISPLAY_INFO_CHANGED
                }
                @Suppress("DEPRECATION")
                tm.listen(listener, events)
            }
        } catch (_: Throwable) {
            // Permission na ho ya OEM rok de to khamoshi se aage —
            // Dart taraf asal haqiqat ("maloom nahi") hi dikhegi.
        }
    }

    // ------------------------------------------------------------------
    // Network
    // ------------------------------------------------------------------

    private fun getNetworkInfo(): Map<String, Any?> {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        var dataType = TelephonyManager.NETWORK_TYPE_UNKNOWN
        var operator = ""
        var inService = lastServiceState?.state == ServiceState.STATE_IN_SERVICE
        var signalDbm: Int? = null

        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            try {
                @Suppress("DEPRECATION")
                dataType = tm.dataNetworkType
            } catch (_: Throwable) {
                // Ijazat na ho to UNKNOWN hi rahega — label 'Maloom nahi'.
            }
            try {
                operator = tm.networkOperatorName ?: ""
            } catch (_: Throwable) {
                operator = ""
            }
            if (lastServiceState == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    inService =
                        tm.serviceState?.state == ServiceState.STATE_IN_SERVICE
                } catch (_: Throwable) {
                    // chhor do — cache wala jawab hi sahi.
                }
            }
            // Signal: pehle listener wala cache, warna seedha parhna.
            var ss: SignalStrength? = lastSignalStrength
            if (ss == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    @Suppress("DEPRECATION")
                    ss = tm.signalStrength
                } catch (_: Throwable) {
                    ss = null
                }
            }
            if (ss != null) {
                signalDbm = extractDbm(ss)
            }
        } catch (_: Throwable) {
            // Telephony hi na mile to khaali jawab — Dart 'maloom nahi'
            // dikhayega.
        }

        var isWifi = false
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE)
                as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (_: Throwable) {
            isWifi = false
        }

        return mapOf(
            "permissionGranted" to granted,
            "operatorName" to operator,
            "dataNetworkType" to dataType,
            "overrideNetworkType" to lastOverrideNetworkType,
            "hasCellService" to inService,
            "signalDbm" to signalDbm,
            "isWifiConnected" to isWifi
        )
    }

    /** SignalStrength se asal dBm — 5G (NR) ko pehle, phir LTE, phir baqi. */
    private fun extractDbm(ss: SignalStrength): Int? {
        return try {
            var bestPriority = Int.MAX_VALUE
            var bestDbm: Int? = null
            for (cell in ss.cellSignalStrengths) {
                val d = try {
                    cell.dbm
                } catch (_: Throwable) {
                    continue
                }
                // Asal dBm hamesha negative hota hai; MAX_VALUE / 0 matlab
                // "maloom nahi" — use kabhi asli number mat bano.
                if (d >= 0 || d < -170 || d == Int.MAX_VALUE) continue
                val priority = when {
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                        cell is CellSignalStrengthNr -> 0
                    cell is CellSignalStrengthLte -> 1
                    else -> 2
                }
                if (priority < bestPriority) {
                    bestPriority = priority
                    bestDbm = d
                }
            }
            bestDbm
        } catch (_: Throwable) {
            null
        }
    }

    private fun requestPhonePermission(result: MethodChannel.Result) {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_PHONE_STATE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            result.success(true)
            return
        }
        if (pendingPermissionResult != null) {
            result.success(false)
            return
        }
        pendingPermissionResult = result
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.READ_PHONE_STATE),
            phonePermRequestCode
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == phonePermRequestCode) {
            val granted = grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted) registerTelephonyListeners()
            pendingPermissionResult?.success(granted)
            pendingPermissionResult = null
        }
        if (requestCode == locationPermRequestCode) {
            val granted = grantResults.any {
                it == PackageManager.PERMISSION_GRANTED
            }
            pendingLocationResult?.success(granted)
            pendingLocationResult = null
        }
    }

    // ------------------------------------------------------------------
    // Settings screens — sirf kholna, khud kuch change nahi karna.
    // ------------------------------------------------------------------

    private fun openFirstAvailable(actions: List<String>): Boolean {
        for (action in actions) {
            try {
                val intent = Intent(action)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                return true
            } catch (_: Throwable) {
                // Agla fallback try karo.
            }
        }
        return false
    }

    // ------------------------------------------------------------------
    // Display — asal supported refresh rates.
    // ------------------------------------------------------------------

    private fun getDisplayInfo(): Map<String, Any?> {
        var current = 0.0
        val rates = mutableListOf<Double>()
        try {
            val disp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                display
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay
            }
            if (disp != null) {
                current = disp.refreshRate.toDouble()
                try {
                    for (mode in disp.supportedModes) {
                        // 0.1 Hz ki darusti — 119.98 jaisi values saaf hon.
                        rates.add(Math.round(mode.refreshRate * 10.0) / 10.0)
                    }
                } catch (_: Throwable) {
                    // supportedModes na mile to sirf current rate hi sahi.
                }
            }
        } catch (_: Throwable) {
            // Display hi na mile to khaali jawab.
        }
        return mapOf(
            "currentHz" to current,
            "supportedHz" to rates
        )
    }

    // ------------------------------------------------------------------
    // Battery — asal level / health / temperature / voltage / cycle /
    // current (BatteryManager + sticky ACTION_BATTERY_CHANGED intent).
    // ------------------------------------------------------------------

    private fun getBatteryInfo(): Map<String, Any?> {
        var level = -1
        var currentNow: Long? = null
        try {
            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            try {
                val v = bm.getLongProperty(
                    BatteryManager.BATTERY_PROPERTY_CURRENT_NOW
                )
                if (v != Long.MIN_VALUE) currentNow = v
            } catch (_: Throwable) {
                currentNow = null
            }
        } catch (_: Throwable) {
            // BatteryManager na mile to -1 / null hi wapas.
        }

        var health = BatteryManager.BATTERY_HEALTH_UNKNOWN
        var tempC: Double? = null
        var voltageV: Double? = null
        var cycleCount = -1
        var plugged = false
        var charging = false
        try {
            val intent = registerReceiver(
                null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            if (intent != null) {
                health = intent.getIntExtra(
                    BatteryManager.EXTRA_HEALTH,
                    BatteryManager.BATTERY_HEALTH_UNKNOWN
                )
                val t = intent.getIntExtra(
                    BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE
                )
                if (t != Int.MIN_VALUE) tempC = t / 10.0
                val v = intent.getIntExtra(
                    BatteryManager.EXTRA_VOLTAGE, Int.MIN_VALUE
                )
                if (v != Int.MIN_VALUE) voltageV = v / 1000.0
                plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                val status = intent.getIntExtra(
                    BatteryManager.EXTRA_STATUS,
                    BatteryManager.BATTERY_STATUS_UNKNOWN
                )
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    cycleCount = intent.getIntExtra(
                        BatteryManager.EXTRA_CYCLE_COUNT, -1
                    )
                }
            }
        } catch (_: Throwable) {
            // Sticky intent na mile to jo mila wahi sahi.
        }

        return mapOf(
            "levelPct" to level,
            "healthCode" to health,
            "tempC" to tempC,
            "voltageV" to voltageV,
            "cycleCount" to cycleCount,
            "plugged" to plugged,
            "isCharging" to charging,
            "currentUa" to currentNow
        )
    }

    // ------------------------------------------------------------------
    // "Battery Bachao" — Usage access + asal top apps.
    // Ye ijazat app khud nahi le sakti; user system ki "Usage access"
    // setting se deta hai. Ijazat na ho to list NAHI banti.
    // ------------------------------------------------------------------

    private fun hasUsageAccess(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Throwable) {
            false
        }
    }

    private fun getUsageTopApps(result: MethodChannel.Result) {
        if (!hasUsageAccess()) {
            result.success(
                mapOf(
                    "granted" to false,
                    "byTime" to emptyList<Map<String, Any?>>(),
                    "byData" to emptyList<Map<String, Any?>>()
                )
            )
            return
        }
        // UsageStats / NetworkStats ki parhai background thread par —
        // natija main thread par hi wapas (MethodChannel ka usool).
        ioExecutor.execute {
            val out = computeUsageTopApps()
            mainHandler.post { result.success(out) }
        }
    }

    /** Pichhle 7 din: foreground waqt aur data kharch ki asal top apps. */
    private fun computeUsageTopApps(): Map<String, Any?> {
        val end = System.currentTimeMillis()
        val begin = end - 7L * 24 * 60 * 60 * 1000
        val pm = packageManager

        fun label(pkg: String): String = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
            pkg
        }

        // Foreground waqt (UsageStatsManager).
        val timeAgg = HashMap<String, Long>()
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE)
                as UsageStatsManager
            val stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_BEST, begin, end
            )
            for (s in stats) {
                if (s.totalTimeInForeground > 0) {
                    timeAgg[s.packageName] =
                        (timeAgg[s.packageName] ?: 0L) + s.totalTimeInForeground
                }
            }
        } catch (_: Throwable) {
            // Data na mile to khaali list — andaza nahi.
        }
        val byTime = timeAgg.entries
            .sortedByDescending { it.value }
            .take(8)
            .map {
                mapOf(
                    "packageName" to it.key,
                    "label" to label(it.key),
                    "foregroundMs" to it.value
                )
            }

        // Data kharch (NetworkStatsManager) — mobile + Wi-Fi jama.
        val uidAgg = HashMap<Int, Long>()
        try {
            val nsm = getSystemService(Context.NETWORK_STATS_SERVICE)
                as NetworkStatsManager
            for (type in intArrayOf(
                ConnectivityManager.TYPE_MOBILE,
                ConnectivityManager.TYPE_WIFI
            )) {
                try {
                    val details = nsm.queryDetails(type, null, begin, end)
                    val bucket = NetworkStats.Bucket()
                    while (details.hasNextBucket()) {
                        details.getNextBucket(bucket)
                        val total = bucket.rxBytes + bucket.txBytes
                        if (total > 0) {
                            uidAgg[bucket.uid] = (uidAgg[bucket.uid] ?: 0L) + total
                        }
                    }
                    details.close()
                } catch (_: Throwable) {
                    // Is network type ka data na mile to chhor do.
                }
            }
        } catch (_: Throwable) {
            // NetworkStats hi na mile to khaali list.
        }
        val pkgAgg = HashMap<String, Long>()
        for ((uid, bytes) in uidAgg) {
            val pkg = try {
                pm.getPackagesForUid(uid)?.firstOrNull()
            } catch (_: Throwable) {
                null
            } ?: continue
            pkgAgg[pkg] = (pkgAgg[pkg] ?: 0L) + bytes
        }
        val byData = pkgAgg.entries
            .sortedByDescending { it.value }
            .take(8)
            .map {
                mapOf(
                    "packageName" to it.key,
                    "label" to label(it.key),
                    "totalBytes" to it.value
                )
            }

        return mapOf(
            "granted" to true,
            "byTime" to byTime,
            "byData" to byData
        )
    }

    // ------------------------------------------------------------------
    // 5G Scanner — location (sirf ijazat par), "Jahan 5G Mila" ki
    // SharedPreferences storage, aur coverage map ke liye browser.
    // Ijazat na ho to granted=false — koi nakli jagah kabhi nahi banti.
    // ------------------------------------------------------------------

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun requestLocationPermission(result: MethodChannel.Result) {
        if (hasLocationPermission()) {
            result.success(true)
            return
        }
        if (pendingLocationResult != null) {
            result.success(false)
            return
        }
        pendingLocationResult = result
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            locationPermRequestCode
        )
    }

    private fun getCurrentLocation(result: MethodChannel.Result) {
        if (!hasLocationPermission()) {
            result.success(
                mapOf(
                    "granted" to false,
                    "lat" to null,
                    "lng" to null,
                    "area" to ""
                )
            )
            return
        }
        // Fresh fix ka intezaar background thread par — main thread
        // block nahi hota; natija main thread par hi wapas jata hai.
        ioExecutor.execute {
            val loc = fetchLocation()
            var area = ""
            if (loc != null) {
                try {
                    val geo = Geocoder(this@MainActivity, Locale.getDefault())
                    @Suppress("DEPRECATION")
                    val results = geo.getFromLocation(
                        loc.latitude, loc.longitude, 1
                    )
                    if (!results.isNullOrEmpty()) {
                        val a = results[0]
                        area = listOfNotNull(a.subLocality, a.locality)
                            .filter { it.isNotEmpty() }
                            .distinct()
                            .joinToString(", ")
                        if (area.isEmpty()) area = a.featureName ?: ""
                    }
                } catch (_: Throwable) {
                    // Geocoder fail ho to coordinates hi kaafi hain.
                    area = ""
                }
            }
            mainHandler.post {
                result.success(
                    mapOf(
                        "granted" to true,
                        "lat" to loc?.latitude,
                        "lng" to loc?.longitude,
                        "area" to area
                    )
                )
            }
        }
    }

    /** Sab se taza last-known fix; purana ho to ek fresh fix ka
     *  (zyada se zyada ~8 second) intezaar. Na mile to null. */
    private fun fetchLocation(): Location? {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        try {
            for (provider in lm.getProviders(true)) {
                try {
                    val l = lm.getLastKnownLocation(provider) ?: continue
                    if (best == null || l.time > best!!.time) best = l
                } catch (_: Throwable) {
                    // Is provider ka fix na mile to agla dekho.
                }
            }
        } catch (_: Throwable) {
            // Providers ki list hi na mile to single update try hoga.
        }
        val fiveMinMs = 5L * 60 * 1000
        if (best != null &&
            System.currentTimeMillis() - best!!.time < fiveMinMs
        ) {
            return best
        }
        val latch = CountDownLatch(1)
        val holder = arrayOfNulls<Location>(1)
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                holder[0] = location
                latch.countDown()
            }

            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(
                provider: String?,
                status: Int,
                extras: Bundle?
            ) {
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        try {
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ->
                    LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ->
                    LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider != null) {
                mainHandler.post {
                    try {
                        @Suppress("DEPRECATION")
                        lm.requestSingleUpdate(
                            provider, listener, Looper.getMainLooper()
                        )
                    } catch (_: Throwable) {
                        latch.countDown()
                    }
                }
                latch.await(8, TimeUnit.SECONDS)
                try {
                    lm.removeUpdates(listener)
                } catch (_: Throwable) {
                    // Listener pehle hi hata ho to koi baat nahi.
                }
            }
        } catch (_: Throwable) {
            // Fresh fix na mile to purana last-known hi wapas jayega.
        }
        return holder[0] ?: best
    }

    private fun readPlacesJson(): String {
        return try {
            getSharedPreferences("fiveg_places", Context.MODE_PRIVATE)
                .getString("places_json", "[]") ?: "[]"
        } catch (_: Throwable) {
            "[]"
        }
    }

    private fun writePlacesJson(json: String): Boolean {
        return try {
            getSharedPreferences("fiveg_places", Context.MODE_PRIVATE)
                .edit()
                .putString("places_json", json)
                .apply()
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** Browser mein di hui (official) site kholta hai. */
    private fun openUrl(url: String): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: Throwable) {
            false
        }
    }
}
