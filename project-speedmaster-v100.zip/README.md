# 5G Speed Master — v1.0.0+1

Bozdar ki asal network/display/battery maloomat wali app (Android, OnePlus 8 5G ke liye bani, har Android 6+ par chalti hai).

**IMAANDARI LOCK:** Ye app signal nahi barhati, speed nahi banati, Hz nahi badhati, charging watts nahi barhati. Jo number dikhta hai woh phone ki asal measurement hai; jo cheez na mil sake wahan saaf "maloom nahi / permission nahi mili" likha aata hai.

## Kya karta hai (sab asal)

- **Live Network Dashboard** — TelephonyManager se asal network type (5G sirf tab jab data type NR ho ya display override NR_NSA/NR_ADVANCED ho), operator ka naam, signal dBm + quality (0–4 bars), har 3 second refresh. READ_PHONE_STATE runtime permission.
- **5G Setting button** — system ki network-operator setting kholta hai (fallbacks ke saath); wahan 'Preferred network type' mein 5G select hota hai.
- **Network Refresh** — airplane-mode setting kholta hai; on/off se phone network dobara dhoondta hai. Koi "signal boost" dawa nahi.
- **Asal Speed Test** — dart:io HttpClient se Cloudflare speed endpoint se asal download naap kar Mbps + ping; test ke waqt ka network label bhi dikhta hai.
- **5G Scanner** — is jagah ki asal haalat + "Jahan 5G Mila" list: asal NR detection par waqt + dBm (+ location ki ijazat ho to coordinates/area) Android SharedPreferences mein mehfooz. Operator ka coverage map browser mein us ki official site par khulta hai — app ke andar koi nakli map nahi.
- **Display** — asal supported refresh rates + abhi wala rate; 120 Hz ka faisla sirf asal list se hota hai (hardcode nahi). "Display Speed Setting Kholein" bara button ACTION_DISPLAY_SETTINGS kholta hai; app khud Hz change nahi karti (system ijazat nahi deta — UI mein saaf likha hai).
- **Battery** — asal level/health/temperature/voltage/cycle count; charging watts taqreeban (|µA| × V), 15W+ par "Fast charging chal rahi hai", warna asal Warp charger ki salah. Battery + Battery Saver settings ke button.
- **Battery Bachao** — Battery Saver setting ka direct button + Usage access (PACKAGE_USAGE_STATS) mili ho to UsageStatsManager/NetworkStatsManager se pichhle 7 din ki asal top apps (istemal + data). Ijazat na ho to grant wala button + saaf note.

## Banawat

- Flutter 3.24.5, sirf platform channels (MethodChannel `com.bozdar.speedmaster/native`) + dart:io — koi heavy plugin nahi.
- Package `com.bozdar.speedmaster` — MainActivity ka package == applicationId.
- Saf logic `lib/logic.dart` mein, unit tests `test/logic_test.dart` + `test/widget_test.dart` mein.
